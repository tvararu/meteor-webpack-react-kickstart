(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/react/react.js                                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
// Write your package code here!                                     // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.react = {};

})();

//# sourceMappingURL=react.js.map
