(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
var ReactRouter = Package['reactrouter:react-router'].ReactRouter;
var FastRender = Package['meteorhacks:fast-render'].FastRender;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var React = Package['react-runtime'].React;

/* Package-scope variables */
var ReactRouterSSR, html;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/reactrouter:react-router-ssr/lib/react-router-ssr.js                          //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
ReactRouterSSR = {};                                                                      // 1
                                                                                          // 2
////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/reactrouter:react-router-ssr/lib/server.jsx.js                                //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
// meteor algorithm to check if this is a meteor serving http request or not
function IsAppUrl(req) {
  var url = req.url;
  if (url === '/favicon.ico' || url === '/robots.txt') {
    return false;
  }

  // NOTE: app.manifest is not a web standard like favicon.ico and
  // robots.txt. It is a file name we have chosen to use for HTML5
  // appcache URLs. It is included here to prevent using an appcache
  // then removing it from poisoning an app permanently. Eventually,
  // once we have server side routing, this won't be needed as
  // unknown URLs with return a 404 automatically.
  if (url === '/app.manifest') {
    return false;
  }

  // Avoid serving app HTML for declared routes such as /sockjs/.
  if (RoutePolicy.classify(url)) {
    return false;
  }

  // we only need to support HTML pages only
  // this is a check to do it
  return /html/.test(req.headers['accept']);
}

var _ReactRouter = ReactRouter;
var Router = _ReactRouter.Router;

var url = Npm.require('url');
var Fiber = Npm.require('fibers');
var cookieParser = Npm.require('cookie-parser');

ReactRouterSSR.Run = function (routes, clientOptions, serverOptions) {
  if (!clientOptions) {
    clientOptions = {};
  }

  if (!serverOptions) {
    serverOptions = {};
  }

  Meteor.bindEnvironment(function () {
    // Parse cookies for the login token
    WebApp.rawConnectHandlers.use(cookieParser());

    WebApp.rawConnectHandlers.use(Meteor.bindEnvironment(function (req, res, next) {
      if (!IsAppUrl(req)) {
        next();
        return;
      }

      var history = ReactRouter.history.createMemoryHistory(req.url);

      var originalSubscribe = Meteor.subscribe;
      var subscriptions = [];

      var path = req.url;
      var loginToken = req.cookies['meteor_login_token'];
      var headers = req.headers;

      var context = new FastRender._Context(loginToken, { headers: headers });

      Meteor.subscribe = function () {
        context.subscribe.apply(context, arguments);
      };

      try {
        FastRender.frContext.withValue(context, function () {
          if (serverOptions.preRender) {
            serverOptions.preRender(req, res);
          }

          html = React.renderToString(React.createElement(Router, babelHelpers._extends({
            history: history,
            children: routes
          }, serverOptions.props)));

          if (serverOptions.postRender) {
            serverOptions.postRender(req, res);
          }
        });

        res.pushData('fast-render-data', context.getData());
      } catch (err) {
        console.error('error while server-rendering', err.stack);
      }

      Meteor.subscribe = originalSubscribe;

      var originalWrite = res.write;
      res.write = function (data) {
        if (typeof data === 'string') {
          data = data.replace('<body>', '<body><div id="' + (clientOptions.rootElement || 'react-app') + '">' + html + '</div>');
        }

        originalWrite.call(this, data);
      };

      next();
    }));
  })();
};////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reactrouter:react-router-ssr'] = {
  ReactRouterSSR: ReactRouterSSR
};

})();

//# sourceMappingURL=reactrouter_react-router-ssr.js.map
