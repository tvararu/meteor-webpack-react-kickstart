(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;

(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/webpack:hot-reload/lib/server.js                                      //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
// Make sure the hot reload is not working in production                          // 1
if (process.env.WEBPACK_CONFIG && process.env.NODE_ENV !== 'production') {        // 2
  var webpack = Npm.require('webpack');                                           // 3
  var config = Npm.require(process.env.WEBPACK_CONFIG);                           // 4
                                                                                  // 5
  var compiler = webpack(config);                                                 // 6
                                                                                  // 7
  WebApp.rawConnectHandlers.use(Npm.require('webpack-dev-middleware')(compiler, { // 8
      noInfo: true,                                                               // 9
      publicPath: config.output.publicPath                                        // 10
  }));                                                                            // 11
                                                                                  // 12
  WebApp.rawConnectHandlers.use(Npm.require('webpack-hot-middleware')(compiler)); // 13
}                                                                                 // 14
                                                                                  // 15
////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webpack:hot-reload'] = {};

})();

//# sourceMappingURL=webpack_hot-reload.js.map
